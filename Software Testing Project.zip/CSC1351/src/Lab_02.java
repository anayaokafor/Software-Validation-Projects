
public class Lab_02 implements MyArray
{

    private static final int max = 100;
    private String[] data;
    private int size;

    public static void main(String[] args) {}

    public void MyArray()
    {
        this.data = new String[max];
        this.size = 0;
    }

    public void MyArray(MyArray Array) {}

    public void MyArray(MyArray Array, int start, int end) {}





    @Override
    public String toString()
    {
        StringBuilder Result = new StringBuilder("{");

        for(int i=0; i<size; i++)
        {
            Result.append(data[i]);
                if(i < size-1){ Result.append(", "); }
        }

        Result.append("}");
        return Result.toString();
    }

    @Override
    public int size()
    {

        String[] array= data;
        int lengthNeeded=array.length;

        return lengthNeeded;
    }

    @Override
    public void set(int pos, String str)
    {

        if(pos >= 0 && pos < size) { data[pos] = str; }

    }

    @Override
    public String get(int pos)
    {

        if (data == null) { return "null"; }

        int length = data.length;
        if (pos < 0 || pos >= length)
        {
            return null;
        }

        String result = data[pos];

        return result;
    }

    @Override
    public int get(String str)
    {

        if (data == null)
        {
            return -1;
        }

        for (int i = 0; i < size; i++)
        {
            if (str.equals(data[i]))
            {
                return i;
            }
        }
        return -1;

    }

    @Override
    public boolean contains(String str)
    {
        if (data == null) { return false; }

        for (int i = 0; i < size; i++)
        {
            if (str.equals(data[i]))
            {
                return true;
            }
        }

        return false;

    }

    @Override
    public void append(String str)
    {
        data[size] = str;
        size++;
    }

    @Override
    public int insert(int pos, String str)
    {
        if (pos < 0 || pos > size) { return -1; }

        for (int i = size; i > pos; i--)
        {
            data[i] = data[i - 1];
        }

        data[pos] = str;
        size++;

        return pos;

    }

    @Override
    public String remove(int pos)
    {
        String removed = data[pos];

        if (pos < 0 || pos >= size) { return null; }


        for (int i = pos; i < size - 1; i++)
        {
            data[i] = data[i + 1];
        }

        data[size - 1] = null;
        size--;

        return removed;
    }

    @Override
    public int remove(String str)
    {
        for (int i = 0; i < size; i++)
        {
            if (str.equals(data[i]))
            {

                for (int j = i; j < size - 1; j++)
                {
                    data[j] = data[j + 1];
                }

                data[size - 1] = null;
                size--;

                return i;
            }
        }

        return -1;
    }
}
