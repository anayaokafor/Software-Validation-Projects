/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package recursionlab;

/**
 *
 * @author steve
 */
import java.util.ArrayList;

public interface PermuteAL {
    /**
     * Creates a sequence of numbers.
     * Thus, sequence(3) generates [0,1,2].
     *
     * @param n
     */
    ArrayList<Integer> sequence(int n);

    /**
     * Permute the elements of the array.
     * Step 1: if the size of the input array, arr, is 1
     *         add it to the result and return it. Done.
     * Step 2: for each element i of the list arr, create
     *         a new and smaller list, sm, with that element removed.
     *         To copy a ArrayList, you can pass it into the constructor
     *         of ArrayList. The code below copies arr into sm.
     *         <pre>
     *         ArrayList<Integer> sm = new ArrayList<>(arr);
     *         </pre>
     * Step 3: call permutation on the smaller list and
     *         store the result in ires.
     * Step 4: for each list in ires, create a new
     *         list by appending the element i of arr.
     *         Add the return value of append to result.
     * Step 5: return the result.
     */
    ArrayList<ArrayList<Integer>> permutation(ArrayList<Integer> arr);
}