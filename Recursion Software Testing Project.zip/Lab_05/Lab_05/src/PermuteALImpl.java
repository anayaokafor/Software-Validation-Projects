import java.util.ArrayList;

public class PermuteALImpl implements recursionlab.PermuteAL {

    @Override
    public ArrayList<Integer> sequence(int n) {
        ArrayList<Integer> result = new ArrayList<>();
        for (int i = 0; i < n; i++) {
            result.add(i);
        }
        return result;
    }

    @Override
    public ArrayList<ArrayList<Integer>> permutation(ArrayList<Integer> arr) {
        ArrayList<ArrayList<Integer>> result = new ArrayList<>();


        if (arr.size() == 1) {
            result.add(arr);
            return result;
        }


        for (int i = 0; i < arr.size(); i++) {
            ArrayList<Integer> sm = new ArrayList<>(arr);
            sm.remove(i);


            ArrayList<ArrayList<Integer>> ires = permutation(sm);


            for (ArrayList<Integer> list : ires) {
                ArrayList<Integer> permuted = new ArrayList<>();
                permuted.add(arr.get(i));
                permuted.addAll(list);


                result.add(permuted);
            }
        }


        return result;
    }
}