import java.util.ArrayList;
import java.util.List;

public class PermuteImpl implements recursionlab.Permute {


    @Override
    public int fac(int n) {
        if (n == 0) {
            return 1;
        }
        return n * fac(n - 1);
    }

    @Override
    public int[] sequence(int n) {
        int[] result = new int[n];
        for (int i = 0; i < n; i++) {
            result[i] = i;
        }
        return result;
    }

    @Override
    public int[] remove(int[] arr, int n) {
        if (n < 0 || n >= arr.length) {
            throw new IllegalArgumentException("Index out of bounds");
        }
        int[] newArr = new int[arr.length - 1];
        int index = 0;
        for (int i = 0; i < arr.length; i++) {
            if (i != n) {
                newArr[index++] = arr[i];
            }
        }
        return newArr;
    }

    @Override
    public int[] append(int[] arr, int elem) {
        int[] newArray = new int[arr.length + 1];
        for (int i = 0; i < arr.length; i++) {
            newArray[i] = arr[i];
        }
        newArray[newArray.length - 1] = elem;
        return newArray;
    }

    @Override
    public int[][] permutation(int[] arr) {
        int[][] result = new int[fac(arr.length)][];
        if (arr.length == 1) {
            result[0] = arr.clone();
            return result;
        } else {
            for (int i = 0; i < arr.length; i++) {
                int[] sm = remove(arr, i);
                int[][] ires = permutation(sm);
                for (int j = 0; j < ires.length; j++) {
                    int[] permuted = new int[arr.length];
                    permuted[0] = arr[i];
                    for (int k = 0; k < ires[j].length; k++) {
                        permuted[k + 1] = ires[j][k];
                    }
                    result[i * ires.length + j] = permuted;
                }
            }
            return result;
        }
    }
}